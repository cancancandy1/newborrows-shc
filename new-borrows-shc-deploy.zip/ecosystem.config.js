module.exports = {
  apps: [
    {
      name: 'new-borrows-shc', 
      script: 'node_modules/next/dist/bin/next',
      args: 'start -p 3024',
      cwd: '/app/web/new-borrows-shc',
      cron_restart: '0 0 * * *', // (Optional) Restart every 00:00 to clear memory
      env_production: {
        LANG: "en_US.UTF-8",
        LC_ALL: "en_US.UTF-8",
        NODE_ENV: 'production',
        PORT: 3024,
        DATABASE_URL: "mysql://root:shc%40dmin2022@localhost:3306/new_borrow_shc?charset=utf8mb4",
        AUTH_URL: "https://shc.sut.ac.th/new-borrows/api/auth",
        NEXTAUTH_URL: "https://shc.sut.ac.th/new-borrows/api/auth",
        AUTH_TRUST_HOST: "true",
        AUTH_SECRET: "m1VjrbViMmhYsJ0tsVi1EswXmWa6NZ1P5PZ1FXXxQBk=",
        NEXT_PUBLIC_BASE_PATH: "/new-borrows",
        SUTSPORT_API_URL: "https://sutsport.sut.ac.th/service/member/code/",
        SUTSPORT_API_TOKEN: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNjMwMzMiLCJqdGkiOiIzMTI3Mzc4Ni04ZWVkLTRhZjQtOGIzMi1iYjg0NTRmYmU4ZjgiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiMjYzMDMzIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjpbIlN0YWZmIiwiTWVtYmVyIl0sImV4cCI6MTY1NTI4MTQ5MSwiaXNzIjoiU01BUlQtU0hDIiwiYXVkIjoiU1RBRkYifQ.0ClLxPWQS25qSDrqXN82DI0-LUruN4loKoOf0XoNkGA"
      },
      // ในกรณีที่ต้องการทำงานที่ sub-path เช่น /new-transfer
      // ต้องตั้งค่าใน next.config.mjs เพิ่มเติม (basePath)
    },
  ],
};
